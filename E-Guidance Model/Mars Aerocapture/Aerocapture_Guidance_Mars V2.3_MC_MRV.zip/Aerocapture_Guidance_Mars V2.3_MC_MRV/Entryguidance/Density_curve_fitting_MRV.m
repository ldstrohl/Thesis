% Do atmo density curve fit from the tabulated Mars GRAM data

clear all
load -ascii GRAM_density.dat
alt= GRAM_density(:,1);
den= GRAM_density(:,2);
cftool(alt,den)