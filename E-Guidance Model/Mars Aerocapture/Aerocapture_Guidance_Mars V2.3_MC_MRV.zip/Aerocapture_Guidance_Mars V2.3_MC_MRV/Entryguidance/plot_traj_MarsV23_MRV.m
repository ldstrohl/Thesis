  clear all
%  close all
load TRAJ1.DAT -ascii    %alpha-q constrained at 500 psf-deg

TRAJ = TRAJ1;
 color = 'g-';
set(0,'DefaultLineLinewidth',2.0);% 0: for all plots
set(0,'DefaultAxesFontSize',12);

%TIME, ALT, ALPHA*C_R2D, ATOTOALQ, PITCH*C_R2D,YAW*C_R2D, ROLL*C_R2D, GAMMAI, V, Q, SIDESLIP*C_R2D
Time    = TRAJ(:,1);
Alt     = TRAJ(:,2);    % geodetic altitude (km)
Lon     = TRAJ(:,3);    % longitude (deg)   
Lat     = TRAJ(:,4);    % geocentric latitude(deg)
V       = TRAJ(:,5);    % relative velocity (m/s)
Gamma   = TRAJ(:,6);    % relative flight-path angle
Bank    = TRAJ(:,7);    % bank angle (deg)
A       = TRAJ(:,8);    % g-load (g)
AOA     = TRAJ(:,9);    % angle of attack (deg)
Mach    = TRAJ(:,10);   % Mach number (197 US Standard Atmosphere)
Q_dot   = TRAJ(:,11);   % heat rate (BTU/ft^2-sec)
qbar    = TRAJ(:,12);   % dynamic pressure (psf)
V_inert = TRAJ(:,13);   % inertial velocity
% CL      = TRAJ(:,14);   % lift coefficient 
% CD      = TRAJ(:,15);   % drag coefficient
% density = TRAJ(:,16);   % air density (kg/m^3)

    figure (4)

    plot(V,Alt,color,'Linewidth',2.0)
    xlabel('relative velocity (m/s)')
    ylabel('geo-detic altitude (km)')
    hold on  

   
    figure (5)
%     subplot(2,1,1)
%     plot(TIME,Alt,color,'Linewidth',2.0)
%     xlabel('time')
%     ylabel('altitude (km)')
%     hold on
%     
%     subplot(2,1,2)
    plot(Time,V,color,'Linewidth',2.0)
    xlabel('time')
    ylabel('relative velocity (m/s)')
    hold on

%      figure (1)
%      plot(Time,AOA,color,'Linewidth',2.0)
%      xlabel('time')
%      ylabel('\alpha (deg)')
%      hold on
%      
%     plot(Lon,Lat,color,'Linewidth',2.0)
%     xlabel('longitude (deg)')
%     ylabel('latitude (deg)')
%     hold on  
%     grid on
%     axis equal


     figure (6)
     plot(Time,Bank,color,'Linewidth',2.0)
     xlabel('time (sec)')
     ylabel('bank angle(deg)')
     hold on   
     grid on
     
 	 figure(9)
    subplot(2,1,1)
    plot(Time,A,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('load factor (Earth g)')
    grid on
    hold on   
    subplot(2,1,2)
    plot(V,Alt,color,'Linewidth',2.0)
    xlabel('velocity (m/s)')
    ylabel('altitude (km)')
    set(gca,'XDir','Reverse')  % Reverse the direction of x-axis
    grid on
    hold on   
     
    figure (10)
    subplot(3,1,1)
    plot(Time,Q_dot,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('heating rate (BTU/ft^2-sec)')
    grid on
    hold on  

    subplot(3,1,2)
    plot(Time,A,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('load factor ( Earth g)')
    grid on
    hold on   


    subplot(3,1,3)
    plot(Time,qbar,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('dynamic pressure(psf)')
    hold on   
    grid on


    t0= 0;
    figure (12)
    subplot(2,1,1)
    plot(Time+t0,Alt,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('geo-detic altitude (km)')
    grid on
    hold on   
    subplot(2,1,2)
    plot(Time+t0,V_inert,color,'Linewidth',2.0)
    xlabel('time (sec)')
    ylabel('inertial velocity (m/s)')
    grid on
    hold on   

    

