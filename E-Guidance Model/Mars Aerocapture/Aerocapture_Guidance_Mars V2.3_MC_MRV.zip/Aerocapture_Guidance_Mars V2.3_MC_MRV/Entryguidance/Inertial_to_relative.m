        
% Compute from a given condition in the ECI frame of the inertial motion
% Find the corresponding condition in relative motion 

        clear all
        ft_to_m    = 0.3048;
        R0         = 6378135.0;   
        r_to_d     = 180.0/pi;
        % Given condition of inertial motion
        x=[R0/ft_to_m+400000, -115.5,-46.66992,36150.0,-5.91,0.0]';

%       x= [6499539.011868435, -117.31580372806096,-9.0185849460382919, 7791.9705028764592,1.1917938663835879,2.0858377459494348]';
   
        r       = x(1);
        theta   = x(2)/r_to_d;
        phi     = x(3)/r_to_d;
        V       = x(4);    
        gamma   = x(5)/r_to_d;
        psi     = x(6)/r_to_d;
        
        
        cs_the  = cos(theta);
        sn_the  = sin(theta);
        cs_phi  = cos(phi);
        sn_phi  = sin(phi);
        rotation= [0, 0, 0.72921151e-4]';   % rad/s
        % Position vector in the ECI frame
        r_I(1)      = r*cs_phi*cs_the;
        r_I(2)      = r*cs_phi*sn_the;
        r_I(3)      = r*sn_phi;
        
        % inertial velocity vector in the LVLH frame 
        V_i(1)    = V*sin(gamma);              
        V_i(2)    = V*cos(gamma)*sin(psi);  
        V_i(3)    = V*cos(gamma)*cos(psi);
        
        V_i       = V_i';
        r_I       = r_I';
        % Transformation matrix from the LVLH frame to the ECI frame
        Ttrans(1,1) = cs_the*cs_phi;
        Ttrans(1,2) =-sn_the;
        Ttrans(1,3) =-cs_the*sn_phi;
        Ttrans(2,1) = sn_the*cs_phi;
        Ttrans(2,2) = cs_the;
        Ttrans(2,3) =-sn_the*sn_phi;
        Ttrans(3,1) = sn_phi;
        Ttrans(3,3) = cs_phi;
        Ttrans(3,2) = 0;
        V_I = Ttrans*V_i;       % inertial velocity in the ECI frame
        
        VRV = cross(rotation, r_I);
        V_rel = V_I - VRV   ;   % relative velocity vector in the ECI frame
        V_r   = norm(V_rel)    % magnitude of relative velocity
        
        V_rel   = inv(Ttrans)*V_rel;  % relative velocity vector in the LVLH frame
        gamma_r = r_to_d* asin(V_rel(1)/V_r)
        psi_r   = r_to_d*atan2(V_rel(2), V_rel(3))
        
        
        