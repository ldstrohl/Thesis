% Make surface plot for sigma_d
% Inverse-distance-weighting interpolation
clear all
close all

color = 'b-';

set(0,'DefaultLineLinewidth',2.0);% 0: for all plots
set(0,'DefaultAxesFontSize',12);

% Define teh input data and format
% Given grid in gamma and V at entry interface
M = 10;  % number of points in gamma
N = 3;  % number of points in V
sigma_d(M,N) = 0;  % initialization

Gamma=[-5.0 -5.2 -5.4 -5.6 -5.9 -6.2 -6.3 -6.4 -6.6 -6.8];  % deg; grid in gamma
V=[10518.5 11018.5 11518.5];       %m/s grid in V
scale = 1.0;
gamma_scale = scale*abs(Gamma(M));
Vscale = V(N);
Gamma = Gamma/gamma_scale;
V=V/Vscale;
% sigma_d is defined only in a band of the MxN matrix sigma_d
% The following defines the first and last elementin in each column
% where sigma_d is defined.
m(1,1) = 1;      % first position defined sigma_d in column 1 
m(2,1) = 4;      % last position of the defined sigma_d in column 1 
m(1,2) = 1;      % first position defined sigma_d in column 2
m(2,2) = 7;      % last position defined sigma_d in column 2
m(1,3) = 2;      % first position defined sigma_d in column 3
m(2,3) = 10;      % last position defined sigma_d in column 3
sigma_d(1)= 102;
sigma_d(2)= 98;
sigma_d(3)= 95;
sigma_d(4)= 90;
sigma_d(5)= 110;
sigma_d(6)= 105;
sigma_d(7)= 102;
sigma_d(8)= 98;
sigma_d(9)= 93;
sigma_d(10)= 90;
sigma_d(11)= 85;
sigma_d(12)= 110;
sigma_d(13)= 108;
sigma_d(14)= 103;
sigma_d(15)= 98;
sigma_d(16)= 94;
sigma_d(17)= 93;
sigma_d(18)= 93;
sigma_d(19)= 90;
sigma_d(20)= 85;



% gamma= -6.2;
% V0  = 11103;
p  = 4;

Dgamma = 0.035/gamma_scale;
DV     = 21/Vscale;
n      = 0;
for I = 1:63
    gamma = Gamma(1)+0.3/gamma_scale - (I-1)*Dgamma;
    Gam(I)=gamma;    
    for J = 1:53
        V0 = V(1)-100/Vscale+(J-1)*DV;
        VV(J) = V0;
        W  = 0.0;
        num = 0;

        for j = 1:N
            for i = m(1,j):m(2,j)
                d =((V(j)-V0)^2+(Gamma(i)-gamma)^2)^(p/2);
                if d == 0
                    k = (i-m(1,j))+num+1; %the number of points covered thus far
                    bank = sigma_d(k);
                    break
                end
                W = W +1/d;
                k = (i-m(1,j))+1+num; %the number of points covered thus far
                W_i(k) = sigma_d(k)/d;
            end
            num = num+(m(2,j)-m(1,j))+1; % num = the number of points covered so far
            
        end 

        bank = 0.0;
        for i =1:num
            bank = bank+W_i(i)/W;
        end
        sigma(I,J) = bank;
    end
end

figure(2)
surf(VV*Vscale/1000, Gam*gamma_scale, sigma)
xlabel('V_0 (km/s)')
ylabel('\gamma_0 (deg)')
zlabel('\sigma_d (deg)')
zlim([60.0,110]);
hold on
