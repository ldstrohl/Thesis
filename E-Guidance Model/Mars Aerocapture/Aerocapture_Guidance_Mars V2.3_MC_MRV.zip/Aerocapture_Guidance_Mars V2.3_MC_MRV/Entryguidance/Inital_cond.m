        
% Compute from given initial condition of relative motion state the 
% orbital plane inclination and ascending node
        clear all
        ft_to_m    = 0.3048;
        R0         = 6378135.0;   
        r_to_d     = 180.0/pi;
        x=[R0/ft_to_m+400000, -166.199408,21.6397649,34787.0,-5.0,40.]';
        
        x=[R0/ft_to_m+400000, -116.5,-46.66992,36150.0,-5.9074,-1.6998]';
 x= [6499.539011868435, -117.31580372806096,-9.0185849460382919, 7.7889966411122596,1.1922489624526598,-1.3579878024308702]';
          
        r       = x(1);
        theta   = x(2)/r_to_d;
        phi     = x(3)/r_to_d;
        V       = x(4);    
        gamma   = x(5)/r_to_d;
        psi     = x(6)/r_to_d;
        cs_the  = cos(theta);
        sn_the  = sin(theta);
        cs_phi  = cos(phi);
        sn_phi  = sin(phi);
        rotation= [0, 0, 0.72921151e-4]'; 
        r_I(1)      = r*cs_phi*cs_the;
        r_I(2)      = r*cs_phi*sn_the;
        r_I(3)      = r*sn_phi;
        V_rel(1)    = V*sin(gamma);              
        V_rel(2)    = V*cos(gamma)*sin(psi);  
        V_rel(3)    = V*cos(gamma)*cos(psi);
        
        V_rel       = V_rel';
        r_I         = r_I';
        
        Ttrans(1,1) = cs_the*cs_phi;
        Ttrans(1,2) =-sn_the;
        Ttrans(1,3) =-cs_the*sn_phi;
        Ttrans(2,1) = sn_the*cs_phi;
        Ttrans(2,2) = cs_the;
        Ttrans(2,3) =-sn_the*sn_phi;
        Ttrans(3,1) = sn_phi;
        Ttrans(3,3) = cs_phi;
        Ttrans(3,2) = 0;
        V_I = Ttrans*V_rel;
        V_rel   = V_I    ;
        VRV = cross(rotation, r_I);
        V_I = V_rel + VRV   ;       % inertial velocity
        h_vec=cross(r_I, V_I);      % compute angular momentum vector
        h=sqrt(dot(h_vec, h_vec));
        incl = acos(h_vec(3)/h)*180/pi     % current orbital inclination 
        k = [0, 0, 1]';
        n = cross(k,h_vec);         % nodal vector
        Omega = acos(n(1)/norm(n))*r_to_d;
        if (n(2)>0) 
            Omega = -Omega
        end
        
        Vi = norm(V_I);
        dummy   = dot(r_I, V_I);
        gamma_i=90-acos(dummy/(r*Vi))*r_to_d
        
        mu  = 3.986012e5;        % km^3/sec^2
        a = -mu/(Vi^2-2*mu/r)
        e = sqrt(1-h^2/(a*mu))
        ha= a*(1+e)-R0/1000
        
        
        
        
        
        