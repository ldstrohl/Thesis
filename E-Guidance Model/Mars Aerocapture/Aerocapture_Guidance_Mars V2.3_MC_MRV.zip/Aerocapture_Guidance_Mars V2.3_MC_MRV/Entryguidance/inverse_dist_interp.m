% Invers-distance-weighting interpolation
clear all
%  close all

color = 'b-';

set(0,'DefaultLineLinewidth',2.0);% 0: for all plots
set(0,'DefaultAxesFontSize',12);

% Define teh input data and format
% Given grid in gamma and V at entry interface
M = 6;  % number of points in gamma
N = 5;  % number of points in V
sigma_d(M,N) = 0;  % initialization

Gamma=[-5.0 -5.5 -6.0 -6.5 -7.0 -7.5];  % deg; grid in gamma
V=[9603 10103 10603 11103 11603];       %m/s grid in V
gamma_scale = abs(Gamma(M));
Vscale = V(N);
Gamma = Gamma/gamma_scale;
V=V/Vscale;

% sigma_d is defined only in a band of the MxN matrix sigma_d
% The following defines the first and last elementin each column
% where sigma_d is defined.
m(1,1) = 1;      % first position defined sigma_d in column 1 
m(2,1) = 2;      % last position of the defined sigma_d in column 1 
m(1,2) = 2;      % first position defined sigma_d in column 2
m(2,2) = 3;      % last position defined sigma_d in column 2
m(1,3) = 2;      % first position defined sigma_d in column 3
m(2,3) = 4;      % last position defined sigma_d in column 3
m(1,4) = 3;      % first position defined sigma_d in column 4
m(2,4) = 5;      % last position defined sigma_d in column 4
m(1,5) = 3;      % first position defined sigma_d in column 5
m(2,5) = 6;      % last position defined sigma_d in column 5

sigma_d(1)= 110;
sigma_d(2)= 140;
sigma_d(3)= 115;
sigma_d(4)= 95;
sigma_d(5)= 130;
sigma_d(6)= 100;
sigma_d(7)= 90;
sigma_d(8)= 120;
sigma_d(9)= 100;
sigma_d(10)= 90;
sigma_d(11)= 120;
sigma_d(12)= 105;
sigma_d(13)= 95;
sigma_d(14)= 95;

gamma= -6.25/gamma_scale;
V0  = 11103/Vscale;
p  = 4;

W  = 0.0;
num = 0;

        for j = 1:N
            for i = m(1,j):m(2,j)
                d =((V(j)-V0)^2+(Gamma(i)-gamma)^2)^(p/2);
                if d == 0
                    k = (i-m(1,j))+num+1; %the number of points covered thus far
                    bank = sigma_d(k)
                    return
                end
                W = W +1/d;
                k = (i-m(1,j))+1+num; %the number of points covered thus far
                W_i(k) = sigma_d(k)/d;
            end
            num = num+(m(2,j)-m(1,j))+1; % num = the number of points covered so far
            
        end 

        bank = 0.0;
        for i =1:num
            bank = bank+W_i(i)/W;
        end
bank



