% states_plot.m

load Final_states.DAT -ascii

states = Final_states;

alt = states(:,1);
apo_vel = states(:,2);
exit_vel = states(:,3);
exit_fpa = states(:,4);
incl = states(:,5);

figure
index = 1:length(alt);
target = 33793*ones(length(alt));
scatter(index,alt)
hold on, plot(index,target,'r-')