clear all
% close all

Gamma=[-5.0 -5.5 -6.0 -6.5 -7.0 -7.5];  % deg; grid in gamma
V=[9603 10103 10603 11103 11603];       %m/s grid in V

M= 6;
N= 5;

m(1,1) = 1;      % first position defined sigma_d in column 1 
m(2,1) = 2;      % last position of the defined sigma_d in column 1 
m(1,2) = 2;      % first position defined sigma_d in column 2
m(2,2) = 3;      % last position defined sigma_d in column 2
m(1,3) = 2;      % first position defined sigma_d in column 3
m(2,3) = 4;      % last position defined sigma_d in column 3
m(1,4) = 3;      % first position defined sigma_d in column 4
m(2,4) = 5;      % last position defined sigma_d in column 4
m(1,5) = 3;      % first position defined sigma_d in column 5
m(2,5) = 6;      % last position defined sigma_d in column 5
iter = 0;

for j = 1:N
    for i = m(1,j):m(2,j)
        iter = iter+1;
        x(iter) = V(j);
        y(iter) = Gamma(i);
    end
end 
figure(1)
plot(x,y,'o');
xlabel('V_0 (m/s)')
ylabel('\gamma_0 (deg)')
hold on
k = convhull(x,y);
plot(x(k),y(k))
hold on

% construct pairs (V0,gamma0)
for i = 1:iter
    Z(1,i) = x(i);
    Z(2,i) = y(i);
end

K = 10;  % total number of trial points to be generated
for i = 1:K   
    sum  = 0;
    for j = 1:iter-1
%          a(j) = (1/(iter-1))*rand;
        a(j) = (1-sum-0.2)*0.6*rand*rand
        sum  = sum+a(j);
    end
    a(iter) = 1.0-sum;

    V0(i)= 0;
    gamma0(i) = 0;
    for j=1:iter
        V0(i) = V0(i)+a(j)*x(iter-j+1);
        gamma0(i) = gamma0(i)+a(j)*y(iter-j+1);
%         V0(i) = V0(i)+a(j)*x(iter-j+1);
%         gamma0(i) = gamma0(i)+a(j)*y(iter-j+1);
    end      
end
plot(V0,gamma0,'x');

for i = 1:K
    X0(i,1) = V0(i);
    X0(i,2) = gamma0(i);
end
 save X0.dat X0 -ascii